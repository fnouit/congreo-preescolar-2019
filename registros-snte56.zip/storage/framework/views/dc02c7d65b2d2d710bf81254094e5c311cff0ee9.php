<?php $__env->startSection('titulo','Busqueda'); ?>
<?php $__env->startSection('container'); ?>            
            <div class="container pt40 pb100 text-uppercase">
                <div class="row text-center">
                    <div class="col-md-6 mr-auto ml-auto">    
                        <?php if(count($usuario)>0): ?>
                            <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                   
                                <h3 class="font300 mb20 h2"><?php echo e($user->nombre); ?>  <span class="text-primary"><?php echo e($user->apellido_p); ?></span></h3>
                                <p>Usuario registrado</p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php else: ?>
                            <h3 class="font300 mb20 h2">SIN  <span class="text-primary">REGISTRO</span></h3>
                            <p>No contamos con ningún registro solicitado con el Número de Personal que nos proporcionaste.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>