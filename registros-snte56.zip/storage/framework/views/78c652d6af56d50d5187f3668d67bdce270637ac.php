<?php $__env->startSection('titulo','Registro'); ?>
<?php $__env->startSection('container'); ?>


<?php $__env->startSection('banner'); ?>

        <section id="home">
            <div id="rev_slider_1078_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="classic4export" data-source="gallery" style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
                <!-- START REVOLUTION SLIDER 5.4.1 auto mode -->
                <div id="rev_slider_1078_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.4.1">
                    <ul>	
                        <li data-index="rs-3045" data-transition="parallaxtoleft" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000" data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off"  data-title="Intro" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                            <img src="images/bg3.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                        </li>
                        <li data-index="rs-3046" data-transition="parallaxtoleft" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="Power4.easeInOut" data-easeout="Power4.easeInOut" data-masterspeed="2000" data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off"  data-title="Intro" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                            <img src="images/bg4.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                        </li>
                    </ul>
                    <div class="tp-bannertimer" style="height: 7px; background-color: rgba(255, 255, 255, 0.25);"></div>	</div>
            </div><!-- END REVOLUTION SLIDER -->
        </section>

<?php $__env->stopSection(); ?>

        <div class="text-center">
        
            <h3 class="font300 mb20  h2">Regístro al <span class="text-primary">evento</span></h3>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger row div-error">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


            <form action="<?php echo e(url('/registro')); ?>" method="post">
            <?php echo e(csrf_field()); ?> 
                <p class="lead">Datos Personales </p>
                <div class="row">
                    <div class="col-sm-6 form-group">      
                        <label for="nombre">INGRESA TÚ NOMBRE</label>          
                        <input id="nombre" type="text" name="nombre" class="form-control gui-input" style='text-transform:uppercase;' placeholder="*" value="<?php echo e(old('nombre')); ?>" >
                    </div>
                    <div class="col-sm-3 form-group">
                        <label for="apellido_paterno">PRIMER APELLIDO</label>          
                        <input id="apellido_paterno" type="text" name="apellido_paterno" class="form-control gui-input " style='text-transform:uppercase' placeholder="*" value="<?php echo e(old('apellido_paterno')); ?>">
                    </div>
                    <div class="col-sm-3 form-group">
                        <label for="apellido_materno">SEGUNDO APELLIDO</label>          
                        <input id="apellido_materno" type="text" name="apellido_materno" class="form-control gui-input" style='text-transform:uppercase' value="<?php echo e(old('apellido_materno')); ?>" >
                    </div>
                </div>                           

                <div class="row">
                    <div class="col-sm-5  form-group">
                        <label for="apellido_materno">CORREO ELECTRÓNICO</label>          
                        <input id="correo" type="email" name="correo" class="form-control" placeholder="*" value="<?php echo e(old('correo')); ?>"  >
                    </div>
                    <div class="col-sm-5  form-group">
                        <label for="rfc">INGRESA TÚ RFC</label>
                        <input id="rfc" type="text" name="rfc" class="form-control" style='text-transform:uppercase' placeholder="*" value="<?php echo e(old('rfc')); ?>" >
                    </div>
                    <div class="col-sm-2  form-group">
                    <label for="genero">GENERO</label>          
                        <select id="genero" name="genero" class="form-control">                            
                            <option></option>                    
                            <option value="OTRO">SIN ESPECIFICAR</option>                    
                            <option value="HOMBRE">HOMBRE</option>
                            <option value="MUJER">MUJER</option>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-4  form-group">
                        <label for="telefono">¿TÚ TELÉFONO ES?</label>
                        <input id="telefono" type="tel" name="telefono" class="form-control" telefono value="<?php echo e(old('telefono')); ?>">
                    </div>
                    <div class="col-sm-4  form-group">
                        <label for="facebook">¿CUÁL ES TU FACEBOOK?</label>
                        <input type="text" id="facebook" name="facebook" class="form-control" value="<?php echo e(old('facebook')); ?>">       
                    </div>
                    <div class="col-sm-4  form-group">
                        <label for="twitter">¿CUÁL ES TU TWITTER?</label>
                        <input type="text" id="twitter" name="twitter" class="form-control" value="<?php echo e(old('twitter')); ?>">
                    </div>                      
                </div> <hr>

                <div class="clearfix pt20" ></div>
                <p class="lead">Datos Laborales </p>  

                <div class="row">
                    <div class="col-xs-12 col-sm-3">
                        <label for="numero_personal">¿TÚ NÚMERO DE PERSONAL ES?</label>
                        <input type="tel" placeholder="*" id="numero_personal" name="numero_personal" class="form-control" value="<?php echo e(old('numero_personal')); ?>">
                    </div>
                    <div class="col-xs-12 col-sm-3">
                        <label for="delegacion">DELEGACIÓN</label>
                        <input type="text" style='text-transform:uppercase' placeholder="*" id="delegacion" name="delegacion"  class="form-control" value="<?php echo e(old('delegacion')); ?>">     
                    </div>
                    <div class="col-xs-12 col-sm-3">
                        <label for="zona_escolar">¿CÚAL ES TU ZONA ESCOLAR?</label>
                        <input type="text" style='text-transform:uppercase' id="zona_escolar" name="zona_escolar" class="form-control" value="<?php echo e(old('zona_escolar')); ?>">     
                    </div>
                    <div class="col-xs-12 col-sm-3">
                        <label for="ct">CLAVE DEL TÚ CENTRO DE TRABAJO</label>
                        <input type="text" style='text-transform:uppercase' id="ct" name="ct" class="form-control" value="<?php echo e(old('ct')); ?>">     
                    </div>
                    <div class="clearfix"></div>            
                </div>

                <div class="row ">
                    <div class="col-xs-12 col-sm-12  form-group pt20">
                        <center><button type="submit" data-btntext-sending="Sending..." class="button btn btn-primary">Regístrate</button></center>
                    </div>
                </div>
            </form>
        </div>

<hr>
        <div class="container pt90 pb60">
            <div id="buscar" class="row align-items-center">
                <div class="col-md-5 mb30">
                    <img src="images/about.png" alt="" class="img-fluid">
                </div>
                <div class="col-md-6 offset-md-1 mb30">
                    <h3 class="font300 mb20 h2">Verifica si ya te has  <span class="text-primary">registrado</span></h3>

                    <p>
                        Si ya te regístrate y deseas verificar tu información por favor ingresa tu Número de personal.
                    </p><br>
                    <form action="<?php echo e(route('buscar')); ?>" method="get">
                    
                        <div class="row">
                            <div class="col-sm-12">
                                <input type="tel" name="np" class="form-control form-control-lg mb20" placeholder="Ingresa tu Número de Personal">
                            </div>
                            <div class="col-md-6">
                                <span><small>Mostramos solo la información solicitada</small></span>
                            </div>
                            <div class="col-md-6 text-right">
                                <button type="submit" class="btn btn-outline-secondary btn-block">Buscar</button>
                            </div>
                        </div>
                    </form>
                </div><!--/div-->
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>