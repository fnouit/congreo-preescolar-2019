<?php $__env->startSection('titulo','Busqueda'); ?>
<?php $__env->startSection('container'); ?>
<div class="row pt50 pb20 ">
                <h3 class="font300 mb20 h3 text-center">Buscar <span class="text-primary"><?php echo e(__('registro')); ?></span></h3>
            </div>
            
            <div class="container pt40 pb100">
                <div class="row text-center">
                    <div class="col-md-6 mr-auto ml-auto">
                        <?php echo e($usuario->nombre); ?>



                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>