<?php $__env->startSection('titulo', 'Inicia sesión'); ?>
<?php $__env->startSection('container'); ?>

            <div class="row align-items-center">
                <div class="col-md-5 mb30">
                    <img src="<?php echo e(asset('images/login.png')); ?>"  alt="" class="img-fluid">
                </div>
                <div class="col-md-6 offset-md-1 mb30">
                    <h3 class="font300 mb20 h2">Inicia <span class="text-primary"><?php echo e(__('sesión')); ?></span></h3>
                    <p>Portal de servicio administrativo para el registro de la convocatoria.</p><br>
                    <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?> form-control-lg mb20" name="email" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('Usuario')); ?>" required>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>                                
                            </div>
                            <div class="col-sm-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> form-control-lg mb20" name="password"  placeholder="<?php echo e(__('Contraseña')); ?>" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="col-sm-6 text-right">
                                <button type="submit" class="btn btn-primary btn-outline-secondary btn-block form-control-lg mb20"><?php echo e(__('Entrar')); ?></button>
                            </div>
                        </div>
                    </form>
                </div><!--/div-->
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>