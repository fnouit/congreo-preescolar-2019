<?php $__env->startSection('title', 'Servicio no disponible'); ?>

<?php $__env->startSection('message', 'Página en mantenimiento.'); ?>

<?php echo $__env->make('errors::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>